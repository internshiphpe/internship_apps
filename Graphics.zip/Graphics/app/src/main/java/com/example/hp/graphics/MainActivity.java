package com.example.hp.graphics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
   Demoview   demoview = new Demoview(this);
      setContentView(demoview);
    }

    private class Demoview extends View{


        public Demoview(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);


            Paint paint = new Paint();
            paint.setStyle(Paint.Style.FILL);
            // make the entire canvas white
           /* paint.setColor(Color.WHITE);
            canvas.drawPaint(paint);
*/
            // draw blue circle

            paint.setColor(Color.BLUE);
            canvas.drawCircle(20, 20, 15, paint);



            // draw green circle

            paint.setColor(Color.GREEN);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawCircle(60, 20, 15, paint);

            // draw red rectangle
            paint.setAntiAlias(false);
            paint.setColor(Color.RED);
            canvas.drawRect(100, 5, 200, 30, paint);

            // draw the rotated text
            canvas.rotate(-45);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawText("Graphics Rotation", 40, 180, paint);


        }



    }
    }

