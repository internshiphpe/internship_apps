package comccc.example.user.internlogin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class Adapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    Adapter.ViewHolder holder;
    public static Attendance_details table1;




    public Adapter(Context context) {
        this.context = context;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return Second.detaillist.size();
    }



    @Override
    public Object getItem(int position) {
        return Second.detaillist.get(position);
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        if(view == null){
            holder = new Adapter.ViewHolder();
            view = inflater.inflate(R.layout.attendance_list,null);
            holder.text1 =(TextView)view.findViewById(R.id.text1);
            holder.text2 =(TextView)view.findViewById(R.id.text2);
            holder.text3 =(TextView)view.findViewById(R.id.text3);


            // view.setTag(holder);
        }else
        {
            holder = (Adapter.ViewHolder)view.getTag();
        }

        table1 = (Attendance_details) getItem(position);

      /*  holder.text1.setTag(table);
        holder.text2.setTag(table);
        holder.text3.setTag(table);
        holder.text4.setTag(table);
        holder.text5.setTag(table);*/


        holder.text1.setText(String.valueOf(table1.getAadhar()));
        holder.text2.setText(String.valueOf(table1.getName()));
        holder.text3.setText(String.valueOf(table1.getUsn()));
     //   holder.text4.setText(String.valueOf(table1.getPercentage()));
        // holder.text5.setText(String.valueOf(table1.getSection()));

        return view;

    }


    public static class ViewHolder{
        TextView text1,text2,text3,text4;
    }
}
