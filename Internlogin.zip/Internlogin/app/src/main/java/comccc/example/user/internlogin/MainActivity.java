package comccc.example.user.internlogin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
EditText username,password;
    Button submit;
    ProgressDialog dialog;
    String URL = "http://192.168.1.22/internlogin/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      //  public static ArrayList<Student_details> detaillist = new ArrayList<Student_details>();
      //  public static Student_details table;

        getSupportActionBar().hide();
        username=(EditText)findViewById(R.id.username);
        //password=(EditText)findViewById(R.id.password);
        submit=(Button)findViewById(R.id.login);
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                        login();

                }
            });
        }

    private void login() {

        final ProgressDialog loading = ProgressDialog.show(this,"Uploading...","Please wait...",false,false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST,URL ,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        loading.dismiss();

                        JSONObject jsonResponse;
                        try {

                            jsonResponse = new JSONObject(response);
                            JSONArray jsonArray = jsonResponse.getJSONArray("products");
                            for (int t = 0; t < jsonArray.length(); t++) {


                               // JSONObject object = jsonArray.getJSONObject(t);
                              //  Marks_details table1 = new Marks_details();
                                //table1.setSubject(object.get("id"));


                                // table1.setAttendence_id(object.getInt("attendence_id"));
                                 // table1.setAadhar(object.getString("aadhar"));
                                //table1.setSsemster(object.getString("ssemster"));
                              //  table1.setSname(object.getString("sname"));
                                //table1.setMarks(object.getString("marks"));
                                Intent i =new Intent(MainActivity.this,Second.class);
                                startActivity(i);

                            }

                        }catch (JSONException e) {
                            Toast.makeText(MainActivity.this,"invlaid credentials",Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                        //Disimissing the progress dialog
                      /*  loading.dismiss();
                        Toast.makeText(MainActivity.this, "Successfully login", Toast.LENGTH_LONG).show();
                        Intent i =new Intent(MainActivity.this,Second.class);
                        startActivity(i);*/
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        //Dismissing the progress dialog
                        loading.dismiss();
                        //Showing toast
                        Toast.makeText(MainActivity.this, volleyError.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                String u1=username.getText().toString().trim();
              //  String p1=password.getText().toString().trim();

                //Creating parameters
                Map<String,String> params = new Hashtable<String, String>();
                //Adding parameters
                params.put("aadhar", u1);


                return params;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }
    }


