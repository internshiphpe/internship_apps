package comccc.example.user.internlogin;

public class Attendance_details {


    int id;
    String aadhar;
    String name;
    String usn;
    String course;
    String semester;
    String section;

    String fname;
    String foccupation;
    String mname;
    String moccupation;
    String dob;
    String caste;
    String religion;
    String bgroup;
    String sex;
    String actual_cat;
    String nationality;
    String pmailid;
    String smailid;
    String smobno;
    String pmobno;
    String cetno;
    String dissue;
    int rank;
    String r_urban;
    String quota;
    String pcollege;
    int marks;
    String percentage;
    String image;
    String hmname;
    String post;
    String address;
    String district;
    String pincode;
    int semid;
    String subject;
    int CI;
    int SE;
    String GR;
    int GP;
    String SGPA;
    String CGPA;
    int pid;
    String names;
    String phone_no;


    public Attendance_details() {


    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    /*   public Student_details(String name, String usn, String course, int semester, String section) {
       this.name=name;
        this.usn=usn;
        this.course=course;
        this.semester=semester;
        this.section=section;
    }*/

    /*   public Student_details(int id, String aadhar, String name, String usn, String course, String semester, String section, String fname, String foccupation, String mname, String moccupation, String dob, String caste, String religion, String bgroup, String sex, String actual_cat, String nationality, String pmailid, String smailid, String smobno, String pmobno, String cetno, String dissue, int rank, String r_urban, String quota, String pcollege, int marks, String percentage) {
           this.id = id;
           this.aadhar = aadhar;
           this.name = name;
           this.usn = usn;
           this.course = course;
           this.semester = semester;
           this.section = section;
           this.fname = fname;
           this.foccupation = foccupation;
           this.mname = mname;
           this.moccupation = moccupation;
           this.dob = dob;
           this.caste = caste;
           this.religion = religion;
           this.bgroup = bgroup;
           this.sex = sex;
           this.actual_cat = actual_cat;
           this.nationality = nationality;
           this.pmailid = pmailid;
           this.smailid = smailid;
           this.smobno = smobno;
           this.pmobno = pmobno;
           this.cetno = cetno;
           this.dissue = dissue;
           this.rank = rank;
           this.r_urban = r_urban;
           this.quota = quota;
           this.pcollege = pcollege;
           this.marks = marks;
           this.percentage = percentage;
       }
   */
    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setFoccupation(String foccupation) {
        this.foccupation = foccupation;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public void setMoccupation(String moccupation) {
        this.moccupation = moccupation;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public void setBgroup(String bgroup) {
        this.bgroup = bgroup;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setActual_cat(String actual_cat) {
        this.actual_cat = actual_cat;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setPmailid(String pmailid) {
        this.pmailid = pmailid;
    }

    public void setSmailid(String smailid) {
        this.smailid = smailid;
    }

  /*  public void setSmobno(int smobno) {
        this.smobno = smobno;
    }


    public void setCetno(int cetno) {
        this.cetno = cetno;
    }*/

    public void setDissue(String dissue) {
        this.dissue = dissue;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public void setR_urban(String r_urban) {
        this.r_urban = r_urban;
    }

    public void setQuota(String quota) {
        this.quota = quota;
    }

    public void setPcollege(String pcollege) {
        this.pcollege = pcollege;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }



    public String getFname() {
        return fname;
    }

    public String getFoccupation() {
        return foccupation;
    }

    public String getMname() {
        return mname;
    }

    public String getMoccupation() {
        return moccupation;
    }

    public String getDob() {
        return dob;
    }

    public String getCaste() {
        return caste;
    }

    public String getReligion() {
        return religion;
    }

    public String getBgroup() {
        return bgroup;
    }

    public String getSex() {
        return sex;
    }

    public String getActual_cat() {
        return actual_cat;
    }

    public String getNationality() {
        return nationality;
    }

    public String getPmailid() {
        return pmailid;
    }

    public String getSmailid() {
        return smailid;
    }

  /*  public int getSmobno() {
        return smobno;
    }


    public int getPmobno() {
        return pmobno;
    }

    public void setPmobno(int pmobno) {
        this.pmobno = pmobno;
    }

    public int getCetno() {
        return cetno;
    }*/

    public String getSmobno() {
        return smobno;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getPmobno() {
        return pmobno;
    }

    public String getCetno() {
        return cetno;
    }

    public void setSmobno(String smobno) {
        this.smobno = smobno;
    }

    public void setPmobno(String pmobno) {
        this.pmobno = pmobno;
    }

    public void setCetno(String cetno) {
        this.cetno = cetno;
    }

    public String getDissue() {
        return dissue;
    }

    public int getRank() {
        return rank;
    }

    public String getR_urban() {
        return r_urban;
    }

    public String getQuota() {
        return quota;
    }

    public String getPcollege() {
        return pcollege;
    }

    public int getMarks() {
        return marks;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAadhar() {
        return aadhar;
    }

    public void setAadhar(String aadhar) {
        this.aadhar = aadhar;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }



    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


    public String getHmname() {
        return hmname;
    }

    public void setHmname(String hmname) {
        this.hmname = hmname;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public int getSemid() {
        return semid;
    }

    public void setSemid(int semid) {
        this.semid = semid;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getCI() {
        return CI;
    }

    public void setCI(int CI) {
        this.CI = CI;
    }

    public int getSE() {
        return SE;
    }

    public void setSE(int SE) {
        this.SE = SE;
    }

    public String getGR() {
        return GR;
    }

    public void setGR(String GR) {
        this.GR = GR;
    }

    public int getGP() {
        return GP;
    }

    public void setGP(int GP) {
        this.GP = GP;
    }

    public String getSGPA() {
        return SGPA;
    }

    public void setSGPA(String SGPA) {
        this.SGPA = SGPA;
    }

    public String getCGPA() {
        return CGPA;
    }


    public void setCGPA(String CGPA) {
        this.CGPA = CGPA;
    }
}





