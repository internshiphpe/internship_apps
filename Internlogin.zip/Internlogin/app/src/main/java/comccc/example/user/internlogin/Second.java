package comccc.example.user.internlogin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

public class Second extends AppCompatActivity {
    String URL = "http://192.168.1.22/internlogin/semester.php";
    public static ArrayList<Attendance_details> detaillist = new ArrayList<Attendance_details>();
    public static Attendance_details table1;
    Spinner spin;
    String sem;
    Adapter adpter1;
    ListView listView;
    String semester[]={"1","2","3","4","5","6"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        spin=(Spinner)findViewById(R.id.spinner);

         ArrayAdapter<String> adapter=new ArrayAdapter<>(Second.this,android.R.layout.simple_spinner_item,semester);
         spin.setAdapter(adapter);
         spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
             @Override
             public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 sem=semester[position];
                 registerUser();
             }

             @Override
             public void onNothingSelected(AdapterView<?> parent) {

             }
         });



    }

    private void registerUser() {



        final ProgressDialog loading = ProgressDialog.show(this,"Uploading...","Please wait...",false,false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST,URL ,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        loading.dismiss();

                        JSONObject jsonResponse;
                        try {

                            jsonResponse = new JSONObject(response);
                            JSONArray jsonArray = jsonResponse.getJSONArray("products");
                            for (int t = 0; t < jsonArray.length(); t++) {

                                JSONObject object = jsonArray.getJSONObject(t);
                                Attendance_details table1 = new Attendance_details();
                                table1.setAadhar(object.getString("aadhar"));
                                table1.setName(object.getString("name"));
                                table1.setUsn(object.getString("usn"));
                                detaillist.add(table1);

                            }

                        }catch (JSONException e) {

                            e.printStackTrace();
                        }

                        listView=(ListView)findViewById(R.id.list);
                        adpter1=new Adapter(Second.this);
                        listView.setAdapter(adpter1);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        //Dismissing the progress dialog
                        loading.dismiss();
                        //Showing toast
                        Toast.makeText(Second.this, volleyError.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String,String> params = new Hashtable<String, String>();

                params.put("sem", sem);


                return params;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);




    }
}
